# Bringing your own data to Amazon Redshift Serverless<a name="serverless-bring-own-data"></a>

In this tutorial, you walk through the process to create an Amazon Redshift Serverless and load your own data\.

**Topics**
+ [Step 1: Set up Amazon Redshift Serverless for the first time](serverless-console-getting-started-own-data.md)
+ [Step 2: Query your own data in Amazon Redshift query editor v2](rs-serverless-console-query-own-data.md)