# Step 1: Set up Amazon Redshift Serverless for the first time<a name="serverless-console-getting-started-own-data"></a>

To set up Amazon Redshift Serverless for the first time, follow the steps in [Step 1: Set up Amazon Redshift Serverless for the first time](serverless-console-getting-started-sample-data.md)\.